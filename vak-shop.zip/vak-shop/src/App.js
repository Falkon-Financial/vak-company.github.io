
import React from "react";
const products = [
  { category: "Perfume", name: "Oud Royale", price: 149.99, image: "https://via.placeholder.com/300x200?text=Oud+Royale" },
  { category: "Perfume", name: "Amber Essence", price: 129.99, image: "https://via.placeholder.com/300x200?text=Amber+Essence" },
  { category: "Electronics", name: "Noise Cancelling Headphones", price: 299.99, image: "https://via.placeholder.com/300x200?text=Headphones" },
  { category: "Electronics", name: "Smart Home Speaker", price: 199.99, image: "https://via.placeholder.com/300x200?text=Smart+Speaker" },
  { category: "Watches", name: "Luxury Gold Watch", price: 499.99, image: "https://via.placeholder.com/300x200?text=Gold+Watch" },
  { category: "Watches", name: "Classic Leather Watch", price: 249.99, image: "https://via.placeholder.com/300x200?text=Leather+Watch" },
  { category: "Phones", name: "VAK XPhone Pro Max", price: 999.99, image: "https://via.placeholder.com/300x200?text=XPhone+Pro+Max" },
  { category: "Phones", name: "VAK Lite Edition", price: 699.99, image: "https://via.placeholder.com/300x200?text=Lite+Edition" },
];
const policies = {
  terms: `By using our website and purchasing our products, you agree to our terms of use. Users must be at least 18 years old and provide accurate billing details. All sales are subject to verification and may be declined for security reasons.`,
  privacy: `We respect your privacy and do not share your personal information with third parties, except as required by law or to fulfill your order. Your payment and personal data is encrypted and secured.`,
  refund: `We accept returns within 14 days of delivery if the product is unused and in original packaging. Refunds are processed within 7 business days. Shipping costs are non-refundable.`,
};
export default function VAKShop() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 text-white p-8">
      <h1 className="text-4xl font-bold text-center mb-12">VAK Luxury Shop</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {products.map((product, index) => (
          <div key={index} className="bg-gray-800 border border-gold text-white rounded-lg overflow-hidden">
            <div className="p-6 space-y-4">
              <img src={product.image} alt={product.name} className="w-full h-40 object-cover rounded-lg" />
              <h2 className="text-xl font-semibold">{product.name}</h2>
              <p className="text-sm text-gray-300">Category: {product.category}</p>
              <p className="text-lg font-bold text-gold">${product.price.toFixed(2)}</p>
              <button className="bg-gold text-black px-4 py-2 rounded hover:bg-yellow-500">Pay by Card</button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-20 space-y-12">
        <div>
          <h3 className="text-2xl font-bold text-gold mb-2">Terms of Use</h3>
          <p className="text-gray-300 text-sm leading-relaxed">{policies.terms}</p>
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gold mb-2">Privacy Policy</h3>
          <p className="text-gray-300 text-sm leading-relaxed">{policies.privacy}</p>
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gold mb-2">Refund Policy</h3>
          <p className="text-gray-300 text-sm leading-relaxed">{policies.refund}</p>
        </div>
      </div>
    </div>
  );
}
